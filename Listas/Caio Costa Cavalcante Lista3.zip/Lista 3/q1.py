#Crie uma lista com o nome das 3 pessoas mais próximas.

lista_de_amigos = ["Camila", "Karla", "Nigel"]

print(lista_de_amigos)