#3. Crie um dicionário vazio filmes = {}. Utilize o nome de um filme como chave. E, como valor,
#outro dicionário contendo o vilão e o ano em que o filme foi lançado. Preencha 5 filmes.

filmes = {}
filmes["senhor dos anéis - sociedade do anel"] = {"Sauron":"2002"}
filmes["star wars iv - nova esperança"] = {"gorvernador Tarkin":"1977"}
filmes["onde os fracos não tem vez"] = {"Anton Chigurh":"2007"}
filmes["o homem nas trevas"] = {"O homem cego":"2016"}
filmes["invocação do mal 1"] = {"Bathsheba":"2013"}
print(filmes)