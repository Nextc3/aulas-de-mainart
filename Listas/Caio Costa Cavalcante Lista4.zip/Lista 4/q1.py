#1.Faça um dicionário com as 5 pessoas mais perto de você, tendo o nome como chave e a cor da
#camisa que está usando como valor.

pessoas_mais_perto = {
    "Luísa" : "verde",
    "Daniela" : "bege",
    "Camila" : "azul",
    "Elfo" : "preto",
    "Orelha" : "marrom"
}

print(pessoas_mais_perto)