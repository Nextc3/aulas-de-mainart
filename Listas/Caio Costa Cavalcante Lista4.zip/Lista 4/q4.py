#4. Crie um dicionário d e coloque nele seus dados: nome, idade, telefone, endereço. Usando o
#dicionário d criado anteriormente, imprima seu nome.


d = {}
d["nome"] = "Caio Costa Cavalcante"
d["idade"] = 32
d["telefone"] = "99999-6666"
d["endereço"] = "av cardeal avelar brandão vilella. Jardim Santo Inácio"
print(d)
print("Imprimindo o nome")
print(d["nome"])