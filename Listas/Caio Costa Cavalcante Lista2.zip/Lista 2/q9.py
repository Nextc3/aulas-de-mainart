#Leia uma frase pelo teclado e a imprima ao contrário. Por exemplo, se a frase for "Manjo muito de
#Python!", a saída deverá ser '!nohtyP ed otium ojnaM'.

frase = input("Digite a frase: ")

print(frase[::-1])