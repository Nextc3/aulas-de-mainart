#6. Se você correr 65 quilômetros em 3 horas, 23 minutos e 17 segundos, qual é a sua velocidade média em m/s?

horas = 3
minutos = 23 
segundos = 17

minutos = minutos + horas * 60
segundos = segundos + minutos * 60

quilometros  = 65
metros = quilometros * 1000

print("Segundos:")
print(segundos)
print("Metros")
print(metros)

resultado = metros / segundos
print("Resultado:")
print(resultado)