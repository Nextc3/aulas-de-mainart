#4. Calcule a área de um círculo de raio r = 2.
#Lembrete: a área de um círculo de raio r é: A∘ = π r2

pi = 3.14159
r = 2
area = pi * r ** 2

print(area)