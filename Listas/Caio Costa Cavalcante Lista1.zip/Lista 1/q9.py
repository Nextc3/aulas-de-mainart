#9. supondo um retângulo de 10cm de base e 5cm de altura, imprimir a seguinte saída perímetro: / área: /
#diagonal:

base = 10
altura = 5
print("Perímetro:")
print((base * 2) + (altura * 2))

print("Área:")
print(base * altura)