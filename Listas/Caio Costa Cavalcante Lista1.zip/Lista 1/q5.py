#Quantos segundos há em 3 horas, 23 minutos e 17 segundos?

horas = 3
minutos = 23 
segundos = 17

minutos = minutos + horas * 60
segundos = segundos + minutos * 60

print(segundos)

