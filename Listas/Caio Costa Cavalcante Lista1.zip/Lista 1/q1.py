#Calcule o resto da divisão de 10 por 3.
print(10%3)