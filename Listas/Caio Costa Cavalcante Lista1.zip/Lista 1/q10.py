#10. dado os valores das variáveis a=5 e b=12, efetuar a troca de forma 
# que (A) passe ter o valor de (B) e vice-versa.
#Apresetar os valores invertidos.

a = 5
b = 12
a,b = b,a

print(a,b)